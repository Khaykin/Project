package b;

public class Person {

	/**this is the id of this object*/
	private int id;
	
	/**this is the name of this person object*/
	private String name;
	
}

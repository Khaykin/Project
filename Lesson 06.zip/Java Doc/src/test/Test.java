package test;

import a.Book;

public class Test {

	public static void main(String[] args) {
		
		Book book = new Book("Java 1", "Eldar", 150);
		book.addAuthor("aaa");
	}
}

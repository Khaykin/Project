package c.inheritance.shapes;

public class Shape {

	private String color;

	public double getArea() {
		return -1;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
